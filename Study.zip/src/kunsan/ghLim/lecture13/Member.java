package kunsan.ghLim.lecture13;


public class Member 
{
	public int membership;
	public String id,password,name;

	public Member(int membership, String id, String password,String name)
	{
		this.membership = membership;
		this.id = id;
		this.password = password;
		this.name = name;
	}
	public int getMemberShip()
	{
		return membership;
	}
	public String getId()
	{
		return id;
	}
	public String getPassword()
	{
		return password;
	}
	public String getName()
	{
		return name;
	}
	public void setMemberShip(int membership)
	{
		this.membership = membership;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public void setName(String name)
	{
		this.name = name;
	}
}
