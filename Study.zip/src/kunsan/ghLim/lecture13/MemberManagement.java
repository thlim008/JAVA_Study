package kunsan.ghLim.lecture13;

import java.util.*;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.*;

import kunsan.ghLim.lecture04.*;

public class MemberManagement {
	Scanner Scan = new Scanner(System.in);
	ArrayList<Member> memberarr = new ArrayList<Member>();

	public void printLecuture13() {
		System.out.println("1) �ű� ȸ������");
		System.out.println("2) ȸ�� ���� ����");
		System.out.println("   1. pass ����");
		System.out.println("   2. �̸� ����");
		System.out.println("3) ȸ�� ����");
		System.out.println("4) ȸ������ ����");
		System.out.println("5) ���� ȭ������");
		System.out.println("���� :");
	}

	public void chooseMenu() {
		int choosenumber = 1;
		boolean breakpoint = false;

		while (true) {
			printLecuture13();
			try {
				choosenumber = Scan.nextInt();
				switch (choosenumber) {
				case 1:
					FirstMenu();
					choosenumber = 0;
					break;
				case 2:
					starttwoMenu();
					choosenumber = 0;
					break;
				case 3:
					startthirdMenu();
					choosenumber = 0;
					break;
				case 4:
					startfourMenu();
					choosenumber = 0;
					break;
				default:
					System.out.println("�ٽ� �Է����ּ���");
				case 5:
					Save(memberarr, "C:\\WorkSpace\\Study\\src\\kunsan\\ghLim\\lecture13\\Member.txt");
					MainMenu SMC = new MainMenu();
					SMC.Menu_Call();
					breakpoint = true;
					break;
				}
				if (breakpoint) {
					break;
				}
			} catch (InputMismatchException e) {
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				continue;
			}

		}
	}

	public void gologin() {
		Read("C:\\WorkSpace\\Study\\src\\kunsan\\ghLim\\lecture13\\Member.txt");
		while (true) {
			System.out.println("id�� password�� �Է��ϼ���.");
			System.out.println("id: ");
			String id = Scan.next();
			System.out.println("password: ");
			String pass = Scan.next();
			for (int i = 0; i < memberarr.size(); i++) {

				if (id.equals(memberarr.get(i).getId()) && pass.equals(memberarr.get(i).getPassword())) {
					chooseMenu();
					break;
				}
			}
		}
	}

	public void FirstMenu() {
		System.out.println("ȸ������(admin-1:member-0)" + "    " + "ID" + "    " + "pass" + "    " + "name");
		int membership = Scan.nextInt();
		Scan.nextLine();
		String id = Scan.next();
		String password = Scan.next();
		String name = Scan.next();
		memberarr.add(new Member(membership, id, password, name));
	}

	public void Save(ArrayList<Member> memberarr, String filePath) {
		Save(memberarr, filePath, false);
	}

	public void Save(ArrayList<Member> memberarr, String filePath, boolean isAppend) {
		String encrypt = "";
		try {
			FileOutputStream fop = new FileOutputStream(filePath, isAppend);
			DataOutputStream dos = new DataOutputStream(fop);

			for (Member member : memberarr) {
				encrypt = Encrypt(member.getPassword(), "key");
				dos.writeUTF(member.getId());
				dos.writeUTF(encrypt);
				dos.writeUTF(member.getName());
				dos.writeInt(member.getMemberShip());
			}
			dos.close();
		} catch (Exception e) {
			System.out.println("DataIOTest : " + e);
		}
	}

	public void Read(String filePath) {
		int membership = 1;
		String id = null;
		String password = null;
		String name = null;
		boolean EOF = false;
		String decrypt = "";

		try {
			FileInputStream fis = new FileInputStream(filePath);
			DataInputStream dis = new DataInputStream(fis);

			while (!EOF) {
				try {
					id = dis.readUTF();
					password = dis.readUTF();
					name = dis.readUTF();
					membership = dis.readInt();

					try {
						decrypt = Decrypt(password, "key");
					} catch (Exception e) {
						System.out.println("DataIOTest : " + e);
					}
					memberarr.add(new Member(membership, id, decrypt, name));

				} catch (EOFException e) {
					EOF = true;
				}
			}
			dis.close();
		} catch (FileNotFoundException e) {
			System.out.println("DataIOTest : " + e);
		} catch (IOException e) {
			System.out.println("DataIOTest : " + e);
		}
	}

	public void starttwoMenu() {
		System.out.println("1. pass ����");
		System.out.println("2. �̸� ����");
		System.out.println("0. ����");
		int choosenumber = Scan.nextInt();
		switch (choosenumber) {
		case 1:
			starttwoOneMenu();
			choosenumber = 0;
			break;
		case 2:
			starttwotwoMenu();
			choosenumber = 0;
			break;
		case 0:
			break;
		}
	}

	public void starttwoOneMenu() {
		System.out.println("password�� ������ id�� �Է��ϼ���:");
		String id = Scan.next();
		for (int i = 0; i < memberarr.size(); i++) {
			if (id.equals(memberarr.get(i).getId()) && memberarr.get(i).getMemberShip() == 1) {
				System.out.println("�ű� password: ");
				String firstpass = Scan.next();
				System.out.println("�ű� password(again):");
				String Secondpass = Scan.next();
				if (firstpass.equals(Secondpass)) {
					memberarr.get(i).setPassword(Secondpass);
					System.out.println(memberarr.get(i).getId() + "���� �н����带 �����߽��ϴ�.");
				} else {
					System.out.println("�ٽ� �Է��ϼ��� ");
				}
			}
		}
	}

	public void starttwotwoMenu() {
		System.out.println("�̸��� ������ id�� �Է��ϼ���:");
		String id = Scan.next();
		for (int i = 0; i < memberarr.size(); i++) {
			if (id.equals(memberarr.get(i).getId()) && memberarr.get(i).getMemberShip() == 1) {
				System.out.println("�ű� name: ");
				String firstName = Scan.next();
				System.out.println("�ű� name(again):");
				String SecondName = Scan.next();
				if (firstName.equals(SecondName)) {
					memberarr.get(i).setName(SecondName);
					System.out.println(memberarr.get(i).getId() + "���� name �����߽��ϴ�.");
				} else {
					System.out.println("�ٽ� �Է��ϼ���");
				}
			}
		}
	}

	public void startthirdMenu() {
		System.out.println("������ id�� �Է��ϼ���");
		String deleteNum = Scan.next();
		for (int i = 0; i < memberarr.size(); i++) {
			if (deleteNum.equals(memberarr.get(i).getId())) {
				memberarr.remove(i);
			}
		}
	}

	public void startfourMenu() {
		System.out.println("���� id pass name");
		System.out.println("=======================");
		for (int i = 0; i < memberarr.size(); i++) {
			System.out.println(memberarr.get(i).getMemberShip() + " " + memberarr.get(i).getId() + " "
					+ memberarr.get(i).getPassword() + " " + memberarr.get(i).getName());
		}
	}

	public static String Decrypt(String text, String key) throws Exception

	{

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] keyBytes = new byte[16];
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length)
			len = keyBytes.length;

		System.arraycopy(b, 0, keyBytes, 0, len);

		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);

		cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);

		Decoder decoder = Base64.getDecoder();

		byte[] results = cipher.doFinal(decoder.decode(text));

		return new String(results, "UTF-8");

	}

	public static String Encrypt(String text, String key) throws Exception

	{

		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

		byte[] keyBytes = new byte[16];

		byte[] b = key.getBytes("UTF-8");

		int len = b.length;

		if (len > keyBytes.length)
			len = keyBytes.length;

		System.arraycopy(b, 0, keyBytes, 0, len);

		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

		IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);

		cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

		byte[] results = cipher.doFinal(text.getBytes("UTF-8"));

		Encoder encoder = Base64.getEncoder();

		return encoder.encodeToString(results);

	}

	public static void main(String[] args) {
		MemberManagement MM = new MemberManagement();
		MM.gologin();
	}
}