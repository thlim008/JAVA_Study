package kunsan.ghLim.lecture04;
import java.util.Scanner;
public class CoffeePrice 
{	
	public void calcPrice()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("���� Ŀ�� �帱���?");
		String order = scanner.next();
		int price =0;
		CoffeePrice2 Cp2 = new CoffeePrice2();
		Cp2.CP2(order, price);
		scanner.close();
	}
}