package kunsan.ghLim.lecture04;

import java.util.Scanner;

public class FourMenu 
{
	public void add()
	{
		int sum = 0;
		Scanner Cal_num = new Scanner(System.in);
		int num1 = Cal_num.nextInt();
		int num2 = Cal_num.nextInt();
		FourMenu2 FM2 = new FourMenu2();
		FM2.Four_Menu2(num1, num2, sum);
		System.out.println();
		MainMenu Whilecall = new MainMenu();
		Whilecall.Menu_Call();
	}
	
}


