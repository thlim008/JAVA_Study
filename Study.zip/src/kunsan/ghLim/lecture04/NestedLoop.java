package kunsan.ghLim.lecture04;

public class NestedLoop 
{
	public void run99()
	{
		for(int i = 1; i< 10; i++,System.out.println())
		{
			for(int j = 1; j< 10; j++,System.out.print('\t'))
			{
				System.out.print(i + "*" + j + "=" + i*j);
			}
		}
		MainMenu Whilecall = new MainMenu();
		Whilecall.Menu_Call();
	}
	
}
