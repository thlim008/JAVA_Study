package kunsan.ghLim.lecture04;

public class DoWhileSample 
{
	public void printAtoZ()
	{
		char a = 'a';
		do 
		{
			System.out.print(a );
			a = (char)(a+1);
			
		}while (a<='z');
		System.out.println("");
		MainMenu Whilecall = new MainMenu();
		Whilecall.Menu_Call();
	}
	
}
