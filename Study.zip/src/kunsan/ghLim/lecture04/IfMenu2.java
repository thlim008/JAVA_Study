package kunsan.ghLim.lecture04;
import kunsan.ghLim.Lecture05.*;
import kunsan.ghLim.lecture06.*;
import kunsan.ghLim.Lecture07.*;
import kunsan.ghLim.Lecture08.*;
import kunsan.ghLim.Lecture10.*;
public class IfMenu2 
{
	public void If_Menu2(int num)
	{
		if(num == 4)
		{
			FourMenu FourAdd = new FourMenu();
			FourAdd.add();
		}
		if(num == 5)
		{
			NestedLoop FiveLoop = new NestedLoop();
			FiveLoop.run99();
		}
		if(num == 6)
		{
			SixMenu Six = new SixMenu();
			Six.Math();
		}
		if(num == 7)
		{
			DevideByZeroHandling Seven = new DevideByZeroHandling ();
			Seven.testSafeException();
		}
		if(num == 8)
		{
			StudentMenu Eight = new StudentMenu();
			Eight.Scan();
		}
		if(num == 9)
		{
			BookMenu Nine = new BookMenu();
			Nine.Menu();
		}
		if(num == 10)
		{
			UnivManagement ten = new UnivManagement();
			ten.chooseMenu();
		}
		if(num == 11)
		{
			UnivManagementArrayList menu = new UnivManagementArrayList();
			menu.chooseMenu();
		}
	}
	
}
