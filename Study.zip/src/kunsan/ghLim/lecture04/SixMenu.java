package kunsan.ghLim.lecture04;


public class SixMenu 
{
	public void Math()
	{
		int first = 1; 
		int Second = 1;
		Six_Menu_IO SM = new Six_Menu_IO();
		SM.SMIO2(first, Second);
	}
}
