package kunsan.ghLim.lecture04;

public class FourMenu2 
{
	public void Four_Menu2(int num1, int num2, int sum) 
	{
		for(int i = num1; i<= num2; i++)
		{
			sum = sum +i;
			System.out.print(i);
			if (i < num2)
			{
				System.out.print("+");	
			}
			else
			{
				System.out.print("=");
				System.out.print(sum);
			}
			
		}
		return;
	}
	
}
