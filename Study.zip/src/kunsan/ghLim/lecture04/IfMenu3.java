package kunsan.ghLim.lecture04;

import java.util.Scanner;

public class IfMenu3 
{
	public void If_Menu3(int num)
	{
		Scanner Cal_num = new Scanner(System.in);
		num = Cal_num.nextInt();
		IfMenu1 If_menu = new IfMenu1();
		If_menu.If_Menu1(num);
		IfMenu2 If_menu2 = new IfMenu2();
		If_menu2.If_Menu2(num);
		Cal_num.close();
	}
	
}
