package kunsan.ghLim.lecture04;
import java.util.InputMismatchException;
import kunsan.ghLim.Lecture05.*;
import kunsan.ghLim.lecture06.*;
public class MainMenu 
{
	
	public void Menu_Call()
	{
			Menu_Print M_Print = new Menu_Print();
			M_Print.MenuPrint();
			int num = 1;
			while (num != 0) 
			{
				IfMenu3 If_menu = new IfMenu3();
				try 
				{
					If_menu.If_Menu3(num);
				}
				catch(InputMismatchException e)
				{
					System.out.println("�Ǽ� �� ���ڿ��� �Է� �� �� �����ϴ�.�ٽ� �Է��ϼ���");
					continue;
				}
				num = 0;
			}				
	}
	public static void main(String[] args) 
	{
		MainMenu Choose = new MainMenu();
		Choose.Menu_Call();
	}
}
