package kunsan.ghLim.lecture04;

public class IfMenu1 
{
	
	public void If_Menu1(int num)
	{
		if(num == 1)
		{
			CoffeePrice CoffeeMenu = new CoffeePrice();
			CoffeeMenu.calcPrice();
		}
		else if(num == 2)
		{
			WhileSample TwoWs = new WhileSample();
			TwoWs.getAverage();
		}
		else if(num == 3)
		{
			DoWhileSample ThreeAZ = new DoWhileSample();
			ThreeAZ.printAtoZ();
		}
	}
	
}
