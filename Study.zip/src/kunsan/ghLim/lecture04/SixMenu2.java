package kunsan.ghLim.lecture04;

import java.util.Scanner;

public class SixMenu2 
{
	public void SM2(int first, int Second) 
	{ 
		System.out.print("��� ������ ��� ������ ���ұ��?(int int)");
		Scanner cs = new Scanner(System.in);
		int third = cs.nextInt();
		int four= cs.nextInt();
		for(int i = first; i<=Second; i++,System.out.println())
		{
			for(int j = third; j <= four; j++,System.out.print('\t'))
			{
				System.out.print(i +"*"+j+"="+i*j);
			}
		}
	 }
}
	

