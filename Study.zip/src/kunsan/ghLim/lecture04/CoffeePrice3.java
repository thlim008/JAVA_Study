package kunsan.ghLim.lecture04;

public class CoffeePrice3 
{
	public void CP3(String order, int price)
	{
		if(price!=0)
		{
			System.out.println(order+"��"+price+"���Դϴ�.");
			MainMenu Coffeecall = new MainMenu();
			Coffeecall.Menu_Call();
		}
	}
	
}
