package kunsan.ghLim.Lecture07;

public class book 
{
	String  title, author;
	int Id, Price;
	public book(int Id, String title, String author, int Price) 
	{
			this.Id = Id;
			this.title = title;
			this.author = author;
			this.Price = Price;
	}
	public int getId() {
		return Id;
	}
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public int getPrice() {
		return Price;
	}
	
}


