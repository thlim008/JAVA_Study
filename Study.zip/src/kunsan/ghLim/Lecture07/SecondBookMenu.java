package kunsan.ghLim.Lecture07;

public class SecondBookMenu 
{
	public void SecondBook(book[] num) 
	{
		System.out.println("- ��ü Book ����Ʈ ����");
		for (int i = 0; i < num.length; i++)
		{
			System.out.println(i+1+": "+num[i].getId()+" "+num[i].getTitle()+" "+num[i].getAuthor()+" "+num[i].getPrice());
		}
	}
}
