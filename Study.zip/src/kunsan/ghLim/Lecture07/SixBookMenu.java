package kunsan.ghLim.Lecture07;
import java.util.Arrays;
public class SixBookMenu 
{
	public void Six_Menu(book[] book)
	{
		kunsan.ghLim.Lecture07.book temp;
		for (int i = 0; i<book.length; i++)
		{
			for (int j = 0; j < book.length-i-1; j++)
			{
				String book1 = book[j].getTitle();
				String book2 = book[j+1].getTitle();
				
				if(book1.compareTo(book2)>0)
				{
					temp = book[j];
					book[j] = book[j+1];
					book[j+1] = temp;
				}	
			}
			
			
		}
		for(int i = 0; i< book.length; i++)
		{
			System.out.println("ID ��:"+book[i].getId()+" å �̸�: "+ book[i].getTitle()+" å ����: "+ book[i].getAuthor()+" å ����: "+ book[i].getPrice());
		}
	}
}
