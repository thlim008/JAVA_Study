package kunsan.ghLim.Lecture07;

public class FiveBookMenu 
{
	public void Five_Menu(book[] book)
	{
		int sum = 0;
		int number = 0;
		int arrSize = book.length;
		float me_result = 0;
		if(arrSize % 2 ==0)
		{
			int a = arrSize/2 ;
			int b = arrSize/2-1;
			me_result = (float)(book[a].getPrice() + book[b].getPrice())/2;
		}
		else 
		{
			int a = arrSize/ 2;
			me_result = book[a].getPrice();
		}
		for(int i = 0; i < book.length; i++)
		{
			sum += book[i].getPrice();
		}
		number = sum/arrSize;
		System.out.println("��հ��� "+ number);
		System.out.println("�߾Ӱ��� "+ me_result);
	}
}
