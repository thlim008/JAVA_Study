package kunsan.ghLim.Lecture07;

public class FourBookMenu 
{
	public void Four_Menu(book[] book)
	{
		int min = book[0].getPrice();
		int max = book[0].getPrice();
		for (int i = 0; i< book.length;i++)
		{
			if(max<book[i].getPrice())
			{
				max = book[i].getPrice();
			}
			if(min>book[i].getPrice())
			{
				min = book[i].getPrice();
			}
		}
		System.out.println("�ְ� ����: "+ max);
		System.out.println("���� ����: "+ min);
	}
}
