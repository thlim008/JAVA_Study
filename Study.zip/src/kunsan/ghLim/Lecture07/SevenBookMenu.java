package kunsan.ghLim.Lecture07;
import java.util.*;
public class SevenBookMenu 
{
	public void Seven_Menu(book[] book)
	{
		String temp1;
		System.out.print("������ �˻� �ұ��?");
		Scanner Scan = new Scanner(System.in);
		String Seven_Scan = Scan.nextLine();
		for (int i = 0; i < book.length; i++)
		{
				temp1 = book[i].getTitle();
				if(temp1.equals(Seven_Scan)) 
				{
					System.out.println("å �̸�: "+book[i].getTitle());
					System.out.println("å ID: "+book[i].getId());
					System.out.println("å ����: "+book[i].getAuthor());
					System.out.println("å ����: "+book[i].getPrice());
				}
		}
	}
	
}
