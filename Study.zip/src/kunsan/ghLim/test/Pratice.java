package kunsan.ghLim.test;

import java.io.*;
import java.util.*;

public class Pratice 
{
	Scanner Scan = new Scanner(System.in);
	ArrayList<Member> memberarr = new ArrayList<Member>();
	public void print() {
		System.out.println("1) �ű� ȸ������");
		System.out.println("2) ȸ�� ���� ����");
		System.out.println("   1. pass ����");
		System.out.println("   2. �̸� ����");
		System.out.println("3) ȸ�� ����");
		System.out.println("4) ȸ�� �̸� ������� ����");
		System.out.println("5) ȸ�� ��ȣ ������� ����");
		System.out.println("0) ����");
	}

	public void chooseMenu() {
		int chooseNumber = 1;
		Read("C:\\WorkSpace\\Study\\src\\kunsan\\ghLim\\test\\test.txt");
		while (chooseNumber != 0)
		{
			print();
			chooseNumber = Scan.nextInt();			
			if (chooseNumber == 1)
			{
				showMenu1();
			} 
			else if (chooseNumber == 2) 
			{
				showMenu2();
			} 
			else if (chooseNumber == 3) 
			{
				showMenu3();
			} 
			else if (chooseNumber == 4) 
			{
				showMenu4();
			} 
			else if (chooseNumber == 5) 
			{
				showMenu5();
			} 
			else if (chooseNumber == 0) 
			{
				Save(memberarr, "C:\\WorkSpace\\Study\\src\\kunsan\\ghLim\\test\\test.txt");
				break;
			}
		}

	}

	public void showMenu1() 
	{
		System.out.println("ȸ������(admin-1:member-0)" + "    " + "ID" + "    " + "pass" + "    " + "name");
		int membership = Scan.nextInt();
		Scan.nextLine();
		String id = Scan.next();
		String password = Scan.next();
		String name = Scan.next();
		memberarr.add(new Member(membership, id, password, name));
	}

	public void Save(ArrayList<Member> memberarr, String filePath) 
	{
		Save(memberarr, filePath, false); //true�� ������ ���� �̾�� false�� ������ ���� �����
	}
	public void Save(ArrayList<Member> memberarr, String filePath, boolean isAppend) 
	{
		try {
			FileOutputStream fop = new FileOutputStream(filePath, isAppend);
			DataOutputStream dos = new DataOutputStream(fop);
			for (Member member : memberarr) {
				dos.writeUTF(member.getId());
				dos.writeUTF(member.getPassword());
				dos.writeUTF(member.getname());
				dos.writeInt(member.getMembership());
			}
			dos.close();
		} catch (Exception e) {
			System.out.println("����ó���� �Ͼ" + e);
		}
	}

	public void Read(String filePath) {
		int membership = 1;
		String id = null;
		String password = null;
		String name = null;
		boolean EOF = false;
		try {
			FileInputStream fis = new FileInputStream(filePath);
			DataInputStream dis = new DataInputStream(fis);
			while (!EOF) {
				try {
					id = dis.readUTF();
					password = dis.readUTF();
					name = dis.readUTF();
					membership = dis.readInt();
					memberarr.add(new Member(membership, id, password, name));
				} catch (EOFException e) {
					EOF = true;
				}
				dis.close();
			}
		}catch(IOException e)
		{
			System.out.println("DataIOTest : " + e);
		}
	}
	public void showMenu2()
	{
		System.out.println("1. pass����");
		System.out.println("2. �̸�����");
		System.out.println("0 ����");
		int choosenumber = Scan.nextInt();
		while(choosenumber != 0)
		{
			if(choosenumber == 1)
			{
				showMenu2_1();
			}
			else if(choosenumber == 2)
			{
				showMenu2_2();
			}
			else if(choosenumber == 0)
			{
				chooseMenu();
			}
		}
	}
	public void showMenu2_1()
	{
		System.out.println("���̵� �Է�");
		String id = Scan.next();
		for(int i = 0; i< memberarr.size(); i++)
		{
			if(memberarr.get(i).getId().equals(id))
			{
				System.out.println("�ű� password");
				String password = Scan.next();
				memberarr.get(i).setPassword(password);
			}
		}
	}
	public void showMenu2_2()
	{
		System.out.println("���̵� �Է�");
		String id = Scan.next();
		for(int i = 0; i< memberarr.size(); i++)
		{
			if(id.equals(memberarr.get(i).getId()))
			{
				System.out.println("�ű� �̸�");
				String name= Scan.next();
				memberarr.get(i).setId(name);
			}
		}
	}
	public void showMenu3()
	{
		System.out.println("������ ID");
		String remove = Scan.next();
		for(int i = 0; i<memberarr.size(); i++)
		{
			if(remove.equals(memberarr.get(i).getId()))
			memberarr.remove(i);
		}
	}
	public void showMenu4()
	{
		ArrayList<Member> memberarrclone = (ArrayList<Member>) memberarr.clone();
		memberarrclone.sort((o1, o2) -> o1.getname().compareTo(o2.getname()));
		for(int i = 0; i < memberarrclone.size(); i++)
		{
			System.out.println(memberarrclone.get(i).getname());
		}
	}
	public void showMenu5()
	{
		ArrayList<Member> memberarrclone = (ArrayList<Member>) memberarr.clone();
		memberarrclone.sort((o1,o2) -> o1.getMembership() - o2.getMembership());
		for(int i = 0; i < memberarrclone.size(); i++)
		{
			System.out.println(memberarrclone.get(i).getMembership());
		}
	}
	public static void main(String[] args) 
	{
		Pratice Pr = new Pratice();
		Pr.chooseMenu();
	}
}
