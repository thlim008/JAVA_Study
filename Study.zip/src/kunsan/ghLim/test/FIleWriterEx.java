package kunsan.ghLim.test;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class FIleWriterEx 
{
	public void writeFile(String filePath)
	{
		Scanner scanner = new Scanner(System.in);
		FileWriter fout = null;
		try
		{
			fout = new FileWriter(filePath);
			while(true)
			{
				String line = scanner.nextLine();
				if(line.length() == 0)
				{
					break;
				}
				fout.write(line, 0, line.length());
				fout.write("\r\n", 0, 2);
			}
			fout.close();
		}catch(IOException e)
		{
			System.out.println("����� ����");
		}
		scanner.close();
	}
	public static void main(String[] args) 
	{
		FIleWriterEx  fwe = new FIleWriterEx ();
		fwe.writeFile("c:\\Temp\\hangul_write.txt");
	}
}
