package kunsan.ghLim.test;

import java.io.*;

public class FileHangulReader 
{
	public void readAndPrintFile(String filePath, String h_encoding)
	{
		InputStreamReader in = null;
		FileInputStream fin = null;
		try {
			fin = new FileInputStream( filePath );
			in = new InputStreamReader(fin, h_encoding ); 
			int c;
			System.out.println("인코딩 문자 집합은 " + in.getEncoding());
			while ((c = in.read()) != -1) 
			{
				System.out.print((char)c);
			}
			in.close();
			fin.close();
		}
		catch (IOException e) {
		System.out.println("입출력 오류");
	}
	
}
	public static void main(String[] args) 
	{
		FileHangulReader fre = new FileHangulReader();
		System.out.println("한글 테스트");
		fre.readAndPrintFile( "C:\\Users\\kyu\\Desktop\\hangul_ms949.txt" , "MS949" );
		fre.readAndPrintFile( "C:\\Users\\kyu\\Desktop\\hangul_ms949.txt" , "UTF8" );
		fre.readAndPrintFile( "C:\\Users\\kyu\\Desktop\\hangul_utf8.txt", "UTF8" );
		fre.readAndPrintFile( "C:\\Users\\kyu\\Desktop\\hangul_utf8.txt", "MS949" );

	}

}
