package kunsan.ghLim.Lecture10;

import kunsan.ghLim.lecture04.*;
import java.util.*;
import kunsan.ghLim.Lecture08.*;

public class UnivManagementArrayList 
{
	Scanner Scan = new Scanner(System.in);
	ArrayList<Person> personArr = new ArrayList<Person>();
	public void showPrint()
	{
		System.out.println("1) ���� ������ ������ �Է�");
		System.out.println("2) ���� ������ ��ü ���");
		System.out.println("3) ���� ������ ���� �˻�");
		System.out.println("4) ���� ������ ������ ����");
		System.out.println("5) ���� ������ ������ ����");
		System.out.println("0) ����");
	}
	public void chooseMenu()
	{
		int choosenumber = 1;
		while(choosenumber!= 0)
		{
			try {
			showPrint();
			choosenumber = Scan.nextInt();
			if(choosenumber == 1)
			{
				showFirstMenu();
			}
			else if(choosenumber == 2)
			{
				SecondMenu();
			}
			else if(choosenumber == 3)
			{
				showThirdMenu();
			}
			else if(choosenumber == 4) 
			{
				showFourMenu();
			}
			else if(choosenumber == 5)
			{
				showFiveMenu();
			}
			else if(choosenumber == 0)
			{
				MainMenu SMC = new MainMenu();
				SMC.Menu_Call();
			}
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				continue;
			}
			catch(NullPointerException e)
			{
				System.out.println("Null���� ���� �Ͽ����ϴ�. �ٽ� ������ �ּ���");
				continue;
			}
		}
	}
	public void showFirstMenu()
	{
		try {
			System.out.println("�� ���� �Է��Ͻðڽ��ϱ�?");
			int personcount = Scan.nextInt();
			personArr = new ArrayList<Person>(personcount);
			for(int i = 0; i<personcount; i++)
			{
				System.out.println("�������� �Է��ϼ���");
				System.out.println("1. �Ϲ��� 2. �л� 3. ������ 4. ���� ");
				int menunumber = Scan.nextInt();
				if(menunumber ==1)
				{
					inputPerson();
				}
				else if(menunumber ==2)
				{
					inputStudent();
				}
				else if(menunumber ==3)
				{
					inputResearcher();
				}
				else if(menunumber ==4)
				{
					inputProfessor();
				}
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}

	}
	public void inputPerson()
	{
		int birthyear = 0;
		System.out.println("�Ϲ����� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		personArr.add(new Person(citizennumber, name, birthyear));
	}
	public void inputStudent()
	{
		int birthyear = 0;
		int studentnumber = 0;
		System.out.println("�л��� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		studentnumber = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		String dept = Scan.next();
		personArr.add(new Student(citizennumber, name, birthyear, studentnumber, dept));
	}
	public void inputResearcher()
	{
		int birthyear = 0;
		int employeeNumber = 0;
		System.out.println("�������� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		employeeNumber = Scan.nextInt();
		Scan.nextLine();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		String dept = Scan.next();
		personArr.add(new Researcher(citizennumber, name, birthyear, employeeNumber, dept));
	}
	public void inputProfessor()
	{
		int birthyear = 0;
		int employeeNumber = 0;
		System.out.println("������ ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		employeeNumber = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		String dept = Scan.next();
		String position = Scan.next();
		personArr.add(new Professor(citizennumber, name, birthyear, employeeNumber, dept, position));
	}
	public void printSecondMenu(ArrayList<Person> PersonArr)
	{
		for(Person p:PersonArr)
		{	
			if(p instanceof Student)
			{
				System.out.println("Student :"+((Student)p).toString());
				continue;
			}
			if(p instanceof Researcher)
			{
				System.out.println("Researcher"+((Researcher)p).toString());
				continue;
			}
			if(p instanceof Professor)
			{
				System.out.println("Professor"+((Professor)p).toString());
				continue;
			}
			if(p instanceof Person)
			{
				System.out.println("person :"+p.toString());
			}
		}
	}
	public void showSecondFirstMenu()
	{
		@SuppressWarnings("unchecked")
		ArrayList<Person> personclone = (ArrayList<Person>)personArr.clone();
		Collections.sort(personclone);
		printSecondMenu(personclone);
	}
	public void showSecondSecondMenu()
	{
		@SuppressWarnings("unchecked")
		ArrayList<Person> personclone = (ArrayList<Person>)personArr.clone();
		compareBirthyear birthyear = new compareBirthyear();
		Collections.sort(personclone, birthyear);
		printSecondMenu(personclone);
	}
	public void showSecondThirdMenu()
	{
		@SuppressWarnings("unchecked")
		ArrayList<Person> personclone = (ArrayList<Person>)personArr.clone();
		compareName name = new compareName();
		Collections.sort(personclone, name);
		printSecondMenu(personclone);
	}
	public void showSecondFourMenu()
	{
		@SuppressWarnings("unchecked")
		ArrayList<Person> personclone = (ArrayList<Person>)personArr.clone();
		compareNamereverse reversename = new compareNamereverse();
		Collections.sort(personclone, reversename);
		printSecondMenu(personclone);
	}
	public void SecondMenu()
	{
		System.out.println("���� ����� �����Ͻÿ�");
		System.out.println("1. ��ü����(�ֹι�ȣ ��)");
		System.out.println("2. birthyear ������ ����");
		System.out.println("3. �̸������� ���� ����");
		System.out.println("4. �̸����� ���� ����");
		int secondmenunumber = -1;
		while(secondmenunumber !=0)
		{
			try {
			secondmenunumber = Scan.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				chooseMenu();
			}
			if(secondmenunumber == 1)
			{
				showSecondFirstMenu();
				break;
			}
			if(secondmenunumber == 2)
			{
				showSecondSecondMenu();
				break;
			}
			if(secondmenunumber == 3)
			{
				showSecondThirdMenu();
				break;
			}
			if(secondmenunumber == 4)
			{
				showSecondFourMenu();
				break;
			}
		}
	}
	public void showThirdMenu()
	{
		System.out.println("�˻� ����� �����Ͻÿ�");
		System.out.println("1. �̸����� �˻�");
		System.out.println("2. ���̷� �˻�");
		System.out.println("3. birthyear ������ �˻�");
		int thirdMenunumber = -1;
		while(thirdMenunumber!= 0)
		{
			try 
			{
			thirdMenunumber = Scan.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				chooseMenu();
			}
			if(thirdMenunumber==1)
			{
				showThirdFirstMenu();
				break;
			}
			if(thirdMenunumber==2)
			{
				showThirdSecondMenu();
				break;
			}
			if(thirdMenunumber==3)
			{
				showThirdThirdMenu();
				break;
			}
		}
	}
	
	public void showThirdFirstMenu()
	{
		System.out.print("�̸����� �˻�");
		String equalsstring = Scan.next();
		for(Person equalsName : personArr)
		{
			if(equalsstring.equals(equalsName.getName()))
			{
				 if(equalsName instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Person)
		 			{
		 				System.out.println("person :"+equalsName.toString());
		 			}
			}
		}
	}
	public void showThirdSecondMenu()
	{
		int equalsFirstAge = 0;
		int equalsSecondAge = 0;
		try {
		System.out.println("���̷� �˻�");
		System.out.print("�ּ� ���� :");
		equalsFirstAge = Scan.nextInt();
		System.out.print("�ִ� ���� :");
		equalsSecondAge = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		for(Person equalsAge2 : personArr)
		{	
			int compareBirthyear = equalsAge2.getBirthyear();
			if((2022 - compareBirthyear+1)>=  equalsFirstAge && ((2022-compareBirthyear+1) <=equalsSecondAge))
			{
				 if(equalsAge2 instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Person)
		 			{
		 				System.out.println("person :"+equalsAge2.toString());
		 			}
			}
		}
	}
	public void showThirdThirdMenu()
	{
		int equalsFirstYear = 0;
		int equalsSecondYear = 0;
		int compareBirthyear;
		try {
		System.out.println("���Ϲ����� �˻�");
		System.out.print("�ּ� ���� :");
		equalsFirstYear= Scan.nextInt();
		System.out.print("�ִ� ���� :");
		equalsSecondYear = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		for(Person equalsYear : personArr)
		{
			compareBirthyear = equalsYear.getBirthyear();
			if((compareBirthyear >=  equalsFirstYear) && (compareBirthyear <= equalsSecondYear))
			{
				 if(equalsYear instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Person)
		 			{
		 				System.out.println("person :"+equalsYear.toString());
		 			}
			}
		}
	}
	public void showFourMenu()
	{
		System.out.println("���� ������ ������ ����");
		System.out.print("������ �ֹι�ȣ : ");
		String fourNumber = Scan.next();
		for(Person equalFour : personArr)
		{
			if(fourNumber.equals(equalFour.getCitizennumber()))
			{
				 if(equalFour instanceof Student)
		 			{
					 	setStudent((Student)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Researcher)
		 			{
		 				setResearcher((Researcher)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Professor)
		 			{
		 				setProfessor((Professor)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Person)
		 			{
		 				setPerson(equalFour);
		 			}
			}
		}
	}
	public void setPerson(Person person)
	{
		person.setCitizennumber(Scan.next());
		person.setName(Scan.next());
		person.setbirthyear(Scan.nextInt());
	}
	public void setStudent(Student student)
	{
		student.setCitizennumber(Scan.next());
		student.setName(Scan.next());
		student.setbirthyear(Scan.nextInt());
		student.setStudentnumber(Scan.nextInt());
		student.setDept(Scan.next());
	}
	public void setResearcher(Researcher researcher)
	{
		researcher.setCitizennumber(Scan.next());
		researcher.setName(Scan.next());
		researcher.setbirthyear(Scan.nextInt());
		researcher.setEmployeeNumber(Scan.nextInt());
		researcher.setDept(Scan.next());
	}
	public void setProfessor(Professor professor)
	{
		professor.setCitizennumber(Scan.next());
		professor.setName(Scan.next());
		professor.setbirthyear(Scan.nextInt());
		professor.setEmployeeNumber(Scan.nextInt());
		professor.setDept(Scan.next());
		professor.setPosition(Scan.next());
	}
	public void showFiveMenu()
	{
		System.out.println("������ �ֹι�ȣ�� �Է��ϼ���");
		String deleteNum = Scan.next();
		for(int i = 0; i<personArr.size(); i++)
		{
			if(deleteNum.equals(personArr.get(i).getCitizennumber()))
			{
					personArr.remove(i);
			}
		}
	}
	public static void main(String[] args) 
	{
		UnivManagementArrayList menu = new UnivManagementArrayList();
		menu.chooseMenu();
	}
}
