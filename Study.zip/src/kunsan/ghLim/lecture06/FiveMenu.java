package kunsan.ghLim.lecture06;
import java.util.*;
public class FiveMenu 
{
	public void FM2(int[] num)
	{
		int sum = 0;
		int number = 0;
		int arrSize = num.length;
		float me_result = 0;
		if(arrSize % 2 ==0)
		{
			int a = arrSize/2 ;
			int b = arrSize/2-1;
			me_result = (float)(num[a] + num[b])/2;
		}
		else 
		{
			int a = arrSize/ 2;
			me_result = num[a];
		}
		for(int i:num)
		{
			sum += i;
		}
		number = sum/arrSize;
		System.out.println("��հ��� "+ number);
		System.out.println("�߾Ӱ��� "+ me_result);
	
	}
}
