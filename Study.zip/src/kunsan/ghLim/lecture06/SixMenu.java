package kunsan.ghLim.lecture06;

import java.util.Arrays;

public class SixMenu 
{
	public void SM(int[] num) 
	{
		int[] sortedArr = null;
		sortedArr = num.clone();
		Arrays.sort(sortedArr);
		int [] result = sortedArr;
		System.out.println(Arrays.toString(result));
	}
}
