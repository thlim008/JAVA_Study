package kunsan.ghLim.lecture06;

public class FourMenu 
{
	public void FM(int[] num)
	{
		int min = num[0];
		int max = num[0];
		for (int i = 0; i< num.length;i++)
		{
			if(max<num[i])
			{
				max = num[i];
			}
			if(min>num[i])
			{
				min = num[i];
			}
		}
		System.out.println("�ְ� ����: "+ max);
		System.out.println("���� ����: "+min);
		
	}
}
