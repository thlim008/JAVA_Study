package kunsan.ghLim.middletest2;

public class CompactDisc 
{
	String number, albumname, singer;
	int price, year, albumcount; 
	public CompactDisc(String number, String albumname, String singer,int price, int year, int albumcount )
	{
		this.number = number;
		this.albumname = albumname;
		this.singer = singer;
		this.price = price;
		this.year = year;
		this.albumcount = albumcount;
	}
	public String getNumber()
	{
		return number;
	}
	public String getlAlbumname()
	{
		return albumname;
	}
	public String getSinger()
	{
		return singer;
	}
	public int getPrice()
	{
		return price;
	}
	public int getYear()
	{
		return year;
	}
	public int getAlbumcount()
	{
		return albumcount;
	}
	public void setNumber(String number)
	{
		this.number = number;
	}
	public void setAlbumname(String albumname)
	{
		this.albumname = albumname;
	}
	public void setSinger(String singer)
	{
		this.singer = singer;
	}
	public void setPrice(int price)
	{
		this.price = price;
	
	}
	public void setYear(int year)
	{
		this.year = year;
	}
	public void setAlbumcount(int albumcount)
	{
		this.albumcount = albumcount;
	}
}
