package kunsan.ghLim.middletest2;
import java.util.*;
public class Function 
{
	Scanner Scan = new Scanner(System.in);
	public int selectCount()
	{
		System.out.println("�Է��� CD�� ������ ��������");
		int selectnumber = Scan.nextInt();
		return selectnumber;
	}
	public CompactDisc[] inputData(int selectnumber)
	{
		
		CompactDisc [] compactdiscarr = new CompactDisc[selectnumber];
		for(int i = 0; i< compactdiscarr.length; i++)
		{
			try {
			System.out.println(i+ "��° CD");
			String number = Scan.next();
			String albumname = Scan.next();
			String singer = Scan.next();
			int price = Scan.nextInt();
			int year = Scan.nextInt();
			int albumcount = Scan.nextInt();
			compactdiscarr[i] = new CompactDisc(number,albumname,singer,price,year,albumcount);
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				Main call = new Main();
				call.chooseMenu();
			}
			catch(NullPointerException e)
			{
				System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
				Main call = new Main();
				call.chooseMenu();
			}
		}
		return compactdiscarr;
	}
	public void showList(CompactDisc[] compactdiscarr)
	{
		System.out.println("���ڵ� ��          ���ݸ�          ���ǰ�          ����          ��ó⵵          �����������");
		for(int i = 0; i< compactdiscarr.length; i++)
		{
			System.out.println(compactdiscarr[i].getNumber()+ "          "+compactdiscarr[i].getlAlbumname()+  "          "+compactdiscarr[i].getSinger()+  "          "+compactdiscarr[i].getPrice()+"          "+ compactdiscarr[i].getYear()+ "          "+compactdiscarr[i].getAlbumcount());
		}
	}
	public void showSinger(CompactDisc[] compactdiscarr)
	{
		try {
		System.out.println("�˻��� ���� ��:");
		String searchsinger = Scan.next();
		for (int i = 0; i < compactdiscarr.length; i++) 
		{
			String search = compactdiscarr[i].getSinger();
			if(searchsinger.equals(search))
			{
				System.out.println(compactdiscarr[i].getNumber()+ "          "+compactdiscarr[i].getlAlbumname()+  "          "+compactdiscarr[i].getSinger()+  "          "+compactdiscarr[i].getPrice()+"          "+ compactdiscarr[i].getYear()+ "          "+compactdiscarr[i].getAlbumcount());
			}
		}
		}
		catch(NullPointerException e)
		{
			System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
			Main call = new Main();
			call.chooseMenu();
		}
	}
	public CompactDisc[] deleteInformation(CompactDisc[] compactdiscarr)
	{
		try {
		  System.out.print("������ ���ڵ� ��ȣ �Է�: "); 
	      String num = Scan.next();
	      int arrlength = compactdiscarr.length;
	      for(int i =0;i< arrlength-1;i++)
	      {
	         if(num.equals(compactdiscarr[i].getNumber())) 
	         {
	         System.out.println(compactdiscarr[i].getNumber()+"�� �����մϴ�");
	         for(int j=0;j< arrlength-1;j++) {
	        	 compactdiscarr[j] = compactdiscarr[j+1];  
	         }        
	         }
	      }
		}
	      catch(NullPointerException e)
		  {
				System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
				Main call = new Main();
				call.chooseMenu();
		  }
	      return compactdiscarr;
	}
	public void showMinmax(CompactDisc[] compactdiscarr)
	{
		try {
		System.out.print("�ּڰ�");
		int min = Scan.nextInt(); 
		System.out.print("�ִ�");
		int max = Scan.nextInt();
		for (int i = 0; i < compactdiscarr.length; i++) 
		{
			 if(compactdiscarr[i].getPrice()>=min) 
			 {
		            if(compactdiscarr[i].getPrice()<=max) {
		            	System.out.println(compactdiscarr[i].getNumber()+ "      "+compactdiscarr[i].getlAlbumname()+  "      "+compactdiscarr[i].getSinger()+  "        "+compactdiscarr[i].getPrice()+"          "+ compactdiscarr[i].getYear()+ "        "+compactdiscarr[i].getAlbumcount());
		     
		            }
			 }   
		}
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			Main call = new Main();
			call.chooseMenu();
		}
		catch(NullPointerException e)
		{
			System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
			Main call = new Main();
			call.chooseMenu();
		}
	}

	public void showSort(CompactDisc[] compactdiscarr)
	{
		CompactDisc temp;
		CompactDisc[] arrclone = compactdiscarr.clone();
		for (int i = 0; i < compactdiscarr.length; i++) 
		{
			for (int j = 0; j < compactdiscarr.length-i-1; j++) 
			{
				String firstalbum = arrclone[j].getlAlbumname();
				String lastalbum = arrclone[j+1].getlAlbumname();
				if(firstalbum.compareTo(lastalbum)>0)
				{
					temp = arrclone[j];
					arrclone[j] = arrclone[j+1];
					arrclone[j+1] = temp;
				}
			}
		}
		for (int i = 0; i < arrclone.length; i++)
		{
			System.out.println(arrclone[i].getNumber()+ "          "+arrclone[i].getlAlbumname()+  "          "+arrclone[i].getSinger()+  "          "+arrclone[i].getPrice()+"          "+ arrclone[i].getYear()+ "          "+arrclone[i].getAlbumcount());
		}
	}
	public CompactDisc[] changeAlbumcount(CompactDisc[] compactdiscarr)
	{
		try {
		System.out.println("��� ���� ������ ������ ���ڵ� ��ȣ");
		String changenumber = Scan.next();
		for (int i = 0; i < compactdiscarr.length; i++) 
		{
			String changeinformationcount = compactdiscarr[i].getNumber();
			if(changenumber.equals(changeinformationcount))
			{
				System.out.println("����"+ changeinformationcount+": "+compactdiscarr[i].getlAlbumname()+"������ ��� ������"+ compactdiscarr[i].getAlbumcount());
				System.out.println("����� ��� �����ұ��?");
				compactdiscarr[i].setAlbumcount(Scan.nextInt());
				System.out.println(compactdiscarr[i].getNumber()+ "          "+compactdiscarr[i].getlAlbumname()+  "          "+compactdiscarr[i].getSinger()+  "          "+compactdiscarr[i].getPrice()+"          "+ compactdiscarr[i].getYear()+ "          "+compactdiscarr[i].getAlbumcount());
			}
		}
		}
		catch(NullPointerException e)
		{
			System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
			Main call = new Main();
			call.chooseMenu();
		}
		return compactdiscarr;
	}
	public CompactDisc[] changeInformation(CompactDisc[] compactdiscarr)
	{
		try {
		System.out.println("������ CD ���ڵ� ��ȣ: ");
		String changenumber = Scan.next();
		for (int i = 0; i < compactdiscarr.length; i++) 
		{
			String changetemp = compactdiscarr[i].getNumber();
			if(changenumber.equals(changetemp))
			{
				System.out.println("���� �Է�:");
				compactdiscarr[i].setNumber(Scan.next());
				compactdiscarr[i].setAlbumname(Scan.next());
				compactdiscarr[i].setSinger(Scan.next());
				compactdiscarr[i].setPrice(Scan.nextInt());
				compactdiscarr[i].setYear(Scan.nextInt());
				compactdiscarr[i].setAlbumcount(Scan.nextInt());
			}
		}
		}
		catch(NullPointerException e)
		{
			System.out.println("NULL ���� �Է��Ͽ����ϴ�.");
			Main call = new Main();
			call.chooseMenu();
		}
		return compactdiscarr;
	}
}

	