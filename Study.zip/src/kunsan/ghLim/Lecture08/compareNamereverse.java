package kunsan.ghLim.Lecture08;

import java.util.Comparator;

public class compareNamereverse implements Comparator<Person>
{
   public int compare(Person firstperson, Person secondperson) 
   {
      return secondperson.getName().compareTo(firstperson.getName());
   }
}
