package kunsan.ghLim.Lecture08;

import java.util.*;
import java.util.Scanner;
import kunsan.ghLim.lecture04.*;
public class UnivManagement 
{
	Scanner Scan = new Scanner(System.in);
	Person[] personArr = null;
	public void showPrint()
	{
		System.out.println("1) ���� ������ ������ �Է�");
		System.out.println("2) ���� ������ ��ü ���");
		System.out.println("3) ���� ������ ���� �˻�");
		System.out.println("4) ���� ������ ������ ����");
		System.out.println("5) ���� ������ ������ ����");
		System.out.println("0) ����");
	}
	public void chooseMenu()
	{
		int choosenumber = 1;
		while(choosenumber!= 0)
		{
			try {
			showPrint();
			choosenumber = Scan.nextInt();
			if(choosenumber == 1)
			{
				personArr= showFirstMenu();
			}
			if(choosenumber == 2)
			{
				SecondMenu(personArr);
			}
			if(choosenumber == 3)
			{
				showThirdMenu(personArr);
			}
			if(choosenumber == 4) 
			{
				showFourMenu(personArr);
			}
			if(choosenumber == 5)
			{
				personArr=showFiveMenu(personArr);
			}
			if(choosenumber == 0)
			{
				MainMenu SMC = new MainMenu();
				SMC.Menu_Call();
			}
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				continue;
			}
			catch(NullPointerException e)
			{
				System.out.println("Null���� ���� �Ͽ����ϴ�. �ٽ� ������ �ּ���");
				continue;
			}
		}
	}

	
	public Person[] showFirstMenu()
	{
		try {
			System.out.println("�� ���� �Է��Ͻðڽ��ϱ�?");
			int personcount = Scan.nextInt();
			personArr = new Person[personcount];
			for(int i = 0; i<personcount; i++)
			{
				System.out.println("�������� �Է��ϼ���");
				System.out.println("1. �Ϲ��� 2. �л� 3. ������ 4. ���� ");
				int menunumber = Scan.nextInt();
				if(menunumber ==1)
				{
					personArr[i] = inputPerson();
				}
				else if(menunumber ==2)
				{
					personArr[i] = inputStudent();
				}
				else if(menunumber ==3)
				{
					personArr[i] = inputResearcher();
				}
				else if(menunumber ==4)
				{
					personArr[i] = inputProfessor();
				}
			}
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
			return personArr;
	}
	public Person inputPerson()
	{
		int birthyear = 0;
		System.out.println("�Ϲ����� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		Person personData = new Person(citizennumber, name, birthyear);
		return personData;
	}
	public Student inputStudent()
	{
		int birthyear = 0;
		int studentnumber = 0;
		System.out.println("�л��� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		studentnumber = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		String dept = Scan.next();
		Student studentData = new Student(citizennumber, name, birthyear, studentnumber, dept);
		return studentData;
	}
	public Researcher inputResearcher()
	{
		int birthyear = 0;
		int employeeNumber = 0;
		System.out.println("�������� ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		employeeNumber = Scan.nextInt();
		Scan.nextLine();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		String dept = Scan.next();
		Researcher researcherData = new Researcher(citizennumber, name, birthyear, employeeNumber, dept);
		return researcherData;
	}
	public Professor inputProfessor()
	{
		int birthyear = 0;
		int employeeNumber = 0;
		System.out.println("������ ������ �Է��ϼ���");
		String citizennumber = Scan.next();
		Scan.nextLine();
		String name = Scan.next();
		try {
		birthyear = Scan.nextInt();
		Scan.nextLine();
		employeeNumber = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		Scan.nextLine();
		String dept = Scan.next();
		String position = Scan.next();
		Professor professorData = new Professor(citizennumber, name, birthyear, employeeNumber, dept, position);
		return professorData;
	}
	public void showSecondFirstMenu(Person[] person)
	{
		Person[] PersonArr = person.clone();
		Arrays.sort(PersonArr);
		for(Person p:PersonArr)
		{	
			if(p instanceof Student)
			{
				System.out.println("Student :"+((Student)p).toString());
				continue;
			}
			if(p instanceof Researcher)
			{
				System.out.println("Researcher"+((Researcher)p).toString());
				continue;
			}
			if(p instanceof Professor)
			{
				System.out.println("Professor"+((Professor)p).toString());
				continue;
			}
			if(p instanceof Person)
			{
				System.out.println("person :"+p.toString());
			}
		}
	}
	public void showSecondSecondMenu(Person[] person)
	{
		Person[] PersonArr = person.clone();
		compareBirthyear birthyear = new compareBirthyear();
		Arrays.sort(PersonArr, birthyear);
         for(Person p : PersonArr) 
         {
        	 if(p instanceof Student)
 			{
 				System.out.println("Student :"+((Student)p).toString());
 				continue;
 			}
 			if(p instanceof Researcher)
 			{
 				System.out.println("Researcher"+((Researcher)p).toString());
 				continue;
 			}
 			if(p instanceof Professor)
 			{
 				System.out.println("Professor"+((Professor)p).toString());
 				continue;
 			}
 			if(p instanceof Person)
 			{
 				System.out.println("person :"+p.toString());
 			}
         }

	}
	public void showSecondThirdMenu(Person[] person)
	{
		Person[] PersonArr = person.clone();
		compareName name = new compareName();
		Arrays.sort(PersonArr, name);
         for(Person p : PersonArr) 
         {
        	 if(p instanceof Student)
 			{
 				System.out.println("Student :"+((Student)p).toString());
 				continue;
 			}
 			if(p instanceof Researcher)
 			{
 				System.out.println("Researcher"+((Researcher)p).toString());
 				continue;
 			}
 			if(p instanceof Professor)
 			{
 				System.out.println("Professor"+((Professor)p).toString());
 				continue;
 			}
 			if(p instanceof Person)
 			{
 				System.out.println("person :"+p.toString());
 			}
         }
	}
	public void showSecondFourMenu(Person[] person)
	{
		Person[] PersonArr = person.clone();
		compareNamereverse reversename = new compareNamereverse();
		Arrays.sort(PersonArr, reversename);
         for(Person p : PersonArr) 
         {
        	 if(p instanceof Student)
 			{
 				System.out.println("Student :"+((Student)p).toString());
 				continue;
 			}
 			if(p instanceof Researcher)
 			{
 				System.out.println("Researcher"+((Researcher)p).toString());
 				continue;
 			}
 			if(p instanceof Professor)
 			{
 				System.out.println("Professor"+((Professor)p).toString());
 				continue;
 			}
 			if(p instanceof Person)
 			{
 				System.out.println("person :"+p.toString());
 			}
         }
	}
	public void SecondMenu(Person[] person)
	{
		System.out.println("���� ����� �����Ͻÿ�");
		System.out.println("1. ��ü����(�ֹι�ȣ ��)");
		System.out.println("2. birthyear ������ ����");
		System.out.println("3. �̸������� ���� ����");
		System.out.println("4. �̸����� ���� ����");
		int secondmenunumber = -1;
		while(secondmenunumber !=0)
		{
			try {
			secondmenunumber = Scan.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				chooseMenu();
			}
			if(secondmenunumber == 1)
			{
				showSecondFirstMenu(person);
				break;
			}
			if(secondmenunumber == 2)
			{
				showSecondSecondMenu(person);
				break;
			}
			if(secondmenunumber == 3)
			{
				showSecondThirdMenu(person);
				break;
			}
			if(secondmenunumber == 4)
			{
				showSecondFourMenu(person);
				break;
			}
		}
	}
	public void showThirdMenu(Person[] person)
	{
		//System.out.println("���� ����� �����Ͻÿ�");
		System.out.println("1. �̸����� �˻�");
		System.out.println("2. ���̷� �˻�");
		System.out.println("3. birthyear ������ �˻�");
		int thirdMenunumber = -1;
		while(thirdMenunumber!= 0)
		{
			try 
			{
			thirdMenunumber = Scan.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
				chooseMenu();
			}
			if(thirdMenunumber==1)
			{
				showThirdFirstMenu(person);
				break;
			}
			if(thirdMenunumber==2)
			{
				showThirdSecondMenu(person);
				break;
			}
			if(thirdMenunumber==3)
			{
				showThirdThirdMenu(person);
				break;
			}
		}
	}
	public void showThirdFirstMenu(Person[] person)
	{
		System.out.print("�̸����� �˻�");
		String equalsstring = Scan.next();
		for(Person equalsName : person)
		{
			if(equalsstring.equals(equalsName.getName()))
			{
				 if(equalsName instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsName).toString());
		 				continue;
		 			}
		 			if(equalsName instanceof Person)
		 			{
		 				System.out.println("person :"+equalsName.toString());
		 			}
			}
		}
	}
	public void showThirdSecondMenu(Person[] person)
	{
		int equalsFirstAge = 0;
		int equalsSecondAge = 0;
		try {
		System.out.println("���̷� �˻�");
		System.out.print("�ּ� ���� :");
		equalsFirstAge = Scan.nextInt();
		System.out.print("�ִ� ���� :");
		equalsSecondAge = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		for(Person equalsAge2 : person)
		{
			if(2022 - equalsAge2.getBirthyear()+1 >=  equalsFirstAge && 2022-equalsAge2.getBirthyear()+1 <=equalsSecondAge  )
			{
				 if(equalsAge2 instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsAge2).toString());
		 				continue;
		 			}
		 			if(equalsAge2 instanceof Person)
		 			{
		 				System.out.println("person :"+equalsAge2.toString());
		 			}
			}
		}
	}
	public void showThirdThirdMenu(Person[] person)
	{
		int equalsFirstYear = 0;
		int equalsSecondYear = 0;
		try {
		System.out.println("���Ϲ����� �˻�");
		System.out.print("�ּ� ���� :");
		equalsFirstYear= Scan.nextInt();
		System.out.print("�ִ� ���� :");
		equalsSecondYear = Scan.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("���ڳ� �Ǽ��� �Է��ϼ̽��ϴ�.");
			chooseMenu();
		}
		for(Person equalsYear : person)
		{
			if(equalsYear.getBirthyear() >=  equalsFirstYear && equalsYear.getBirthyear() <=equalsSecondYear)
			{
				 if(equalsYear instanceof Student)
		 			{
		 				System.out.println("Student :"+((Student)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Researcher)
		 			{
		 				System.out.println("Researcher"+((Researcher)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Professor)
		 			{
		 				System.out.println("Professor"+((Professor)equalsYear).toString());
		 				continue;
		 			}
		 			if(equalsYear instanceof Person)
		 			{
		 				System.out.println("person :"+equalsYear.toString());
		 			}
			}
		}
	}
	public void showFourMenu(Person[] person)
	{
		System.out.println("���� ������ ������ ����");
		System.out.print("������ �ֹι�ȣ : ");
		String fourNumber = Scan.next();
		for(Person equalFour : person)
		{
			if(fourNumber.equals(equalFour.getCitizennumber()))
			{
				 if(equalFour instanceof Student)
		 			{
					 	setStudent((Student)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Researcher)
		 			{
		 				setResearcher((Researcher)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Professor)
		 			{
		 				setProfessor((Professor)equalFour);
		 				continue;
		 			}
		 			if(equalFour instanceof Person)
		 			{
		 				setPerson(equalFour);
		 			}
			}
		}
	}
	public void setPerson(Person person)
	{
		person.setCitizennumber(Scan.next());
		person.setName(Scan.next());
		person.setbirthyear(Scan.nextInt());
	}
	public void setStudent(Student student)
	{
		student.setCitizennumber(Scan.next());
		student.setName(Scan.next());
		student.setbirthyear(Scan.nextInt());
		student.setStudentnumber(Scan.nextInt());
		student.setDept(Scan.next());
	}
	public void setResearcher(Researcher researcher)
	{
		researcher.setCitizennumber(Scan.next());
		researcher.setName(Scan.next());
		researcher.setbirthyear(Scan.nextInt());
		researcher.setEmployeeNumber(Scan.nextInt());
		researcher.setDept(Scan.next());
	}
	public void setProfessor(Professor professor)
	{
		professor.setCitizennumber(Scan.next());
		professor.setName(Scan.next());
		professor.setbirthyear(Scan.nextInt());
		professor.setEmployeeNumber(Scan.nextInt());
		professor.setDept(Scan.next());
		professor.setPosition(Scan.next());
	}
	public Person[] showFiveMenu(Person[] person)
	{
		System.out.println("������ �ֹι�ȣ�� �Է��ϼ���");
		String deleteNum = Scan.next();
		int perlength = person.length;
		Person[] temp = new Person[perlength-1];
		for(int i = 0; i<perlength-1; i++)
		{
			if(deleteNum.equals(person[i].getCitizennumber()))
			{
				for(int j = 0; j<perlength-1; j++)
				{
					person[j] = person[j+1]; 
				}
			}
			temp[i] = person[i];
		}
		return temp;
	}
	public static void main(String[] args) 
	{
		UnivManagement menu = new UnivManagement();
		menu.chooseMenu();
	}
	
}
