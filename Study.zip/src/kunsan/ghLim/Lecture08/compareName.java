package kunsan.ghLim.Lecture08;

import java.util.Comparator;

public class compareName implements Comparator<Person>
{
   public int compare(Person firstperson, Person secondperson) 
   {
      return firstperson.getName().compareTo(secondperson.getName());
   }
}
