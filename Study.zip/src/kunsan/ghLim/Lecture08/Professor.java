package kunsan.ghLim.Lecture08;

public class Professor extends Researcher
{
	String position;
	public Professor(String citizennumber, String name, int birthyear, int employeeNumber, String dept, String position) 
	{
		super(citizennumber, name, birthyear, employeeNumber, dept);
		this.position = position;
	}
	public String getPosition()
	{
		return position;
	}
	public void setPosition(String position)
	{
		this.position = position;
	}
	public String toString()
	{
		return citizennumber + "     " + name +"    "+birthyear+"     "+employeeNumber+"    "+dept + "   "+position;
	}
}
