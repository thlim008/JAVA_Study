package kunsan.ghLim.Lecture08;

import java.util.Comparator;

public class compareBirthyear implements Comparator<Person> 
{
	public int compare(Person firstperson, Person secondperson) 
	{
		return firstperson.getBirthyear() - secondperson.getBirthyear();
	}
}