package kunsan.ghLim.Lecture08;

public class Researcher extends Person
{
	int employeeNumber;
	String dept;
	public Researcher(String citizennumber, String name, int birthyear, int employeeNumber, String dept) 
	{
		super(citizennumber, name, birthyear);
		this.employeeNumber = employeeNumber;
		this.dept = dept;

	}
	public int getEmployeeNumber()
	{
		return employeeNumber;
	}
	public String getDept()
	{
		return dept;
	}
	public void setEmployeeNumber(int employeeNumber)
	{
		this.employeeNumber = employeeNumber;
	}
	public void setDept(String dept)
	{
		this.dept = dept;
	}
	public String toString()
	{
		return citizennumber + "    " + name +"    "+birthyear+"    "+employeeNumber+"     "+dept;
	}
}