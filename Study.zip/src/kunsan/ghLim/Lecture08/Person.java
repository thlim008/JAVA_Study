 package kunsan.ghLim.Lecture08;
import java.util.*;
public class Person implements Comparable<Person>
{
	int birthyear;
	String citizennumber,name;
	public Person(String citizennumber, String name, int birthyear)
	{
		this.citizennumber = citizennumber;
		this.name = name;
		this.birthyear = birthyear;
	}
	public String getCitizennumber()
	{
		return citizennumber;
	}
	public String getName()
	{
		return name;
	}
	public int getBirthyear()
	{
		return birthyear;
	}
	public void setCitizennumber(String citizennumber)
	{
		this.citizennumber = citizennumber;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setbirthyear(int birthyear)
	{
		this.birthyear = birthyear;
	}
	public String toString()
	{
		return citizennumber +"       "+ name+"      "+birthyear;
	}
	public int compareTo(Person person)
	{
		return this.getCitizennumber().compareTo(person.getCitizennumber());
	}
}
	

	

	

