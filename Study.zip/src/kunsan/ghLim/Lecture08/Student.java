package kunsan.ghLim.Lecture08;

public class Student extends Person
{
	int studentnumber;
	String dept;
	public Student(String citizennumber, String name, int birthyear, int studentnumber, String dept) 
	{
		super(citizennumber, name, birthyear);
		this.studentnumber = studentnumber;
		this.dept = dept;
	}
	public int getStudentnumber()
	{
		return studentnumber;
	}
	public String getDept()
	{
		return dept;
	}
	public void setStudentnumber(int studentnumber)
	{
		this.studentnumber = studentnumber;
	}
	public void setDept(String dept)
	{
		this.dept = dept;
	}
	public String toString()
	{
		return citizennumber + "      " + name +"      "+birthyear+"    "+studentnumber+"     "+dept;
	}
}