package Project;

public class JAVA 
{
	int BookNumber, BookAge, BookPrice, BookCount;
	String BookName, BookAdder, BookSaler;
	public JAVA(int BookNumber, int BookAge, int BookPrice, int BookCount, String BookName, String BookAdder, String BookSaler)
	{
		this.BookNumber = BookNumber;
		this.BookAge = BookAge;
		this.BookPrice = BookPrice;
		this.BookCount = BookCount;
		this.BookName = BookName;
		this.BookAdder = BookAdder;
		this.BookSaler = BookSaler;
	}
	public int getBookNumber()
	{
		return BookNumber;
	}
	public int getBookAge()
	{
		return BookAge;
	}
	public int getBookPrice()
	{
		return BookPrice;
	}
	public int getBookCount()
	{
		return BookCount;
	}
	public String getBookName()
	{
		return BookName;
	}
	public String getBookAdder()
	{
		return BookAdder;
	}
	public String getBookSaler()
	{
		return BookSaler;
	}
	public void setBookNumber(int BookNumber)
	{
		this.BookNumber = BookNumber;
	}
	public void setBookAge(int BookNumber)
	{
		this.BookNumber = BookNumber;
	}
}
