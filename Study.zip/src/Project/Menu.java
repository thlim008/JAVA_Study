package Project;

public class Menu 
{
	public void print()
	{
		System.out.print(false);
	}
}
