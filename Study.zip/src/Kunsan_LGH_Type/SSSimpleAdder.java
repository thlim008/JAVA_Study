package Kunsan_LGH_Type;

public class SSSimpleAdder 
{
	public void add()
	{
		double num;
		num = 3.14 + 1;
		System.out.println(num);
	}
	public static void main(String[] args) 
	{
		SSSimpleAdder adder = new SSSimpleAdder();
		adder.add();
	}
}
