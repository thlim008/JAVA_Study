package Kunsan_LGH_Type;

public class SSimpleAdder 
{
	public void add() 
	{
		int num;
		num = 1000000000 + 2000000000;
		System.out.println(num);
	}
	public static void main(String[] args) 
	{
		SSimpleAdder adder = new SSimpleAdder();
		adder.add();
	}

}
