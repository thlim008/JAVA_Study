package Kunsan_LGH_Type;

public class TypeExample1 
{
	public void runType()
	{
		double smallest1 = 4.9e-324;
		double smallest2 = -4.9e-324;
		double result1, result2;
		result1 = smallest1 / 2.0;
		result2 = smallest2 / 2.0;
		System.out.println("result1 = " + result1);
		System.out.println("result2 = " + result2);
	}
	public static void main(String[] args) 
	{
		TypeExample1 test = new TypeExample1();
		test.runType();
	}
}	
