package Kunsan_LGH_Type;

public class TypeExample2 
{
	public void runType2()
	{
		double result1, result2;
		result1 = 2.0 / 0.0;
		result2 = 2.0 / -0.0;
		System.out.println("result1 = " + result1);
		System.out.println("result2 = " + result2);
	}
	public static void main(String[] args) 
	{
		TypeExample2 test = new TypeExample2();
		test.runType2();
	}
}
