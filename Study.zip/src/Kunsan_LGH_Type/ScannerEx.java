package Kunsan_LGH_Type;

import java.util.Scanner;
public class ScannerEx 
{
	public void getInput() 
	{ 
		System.out.println("�̸�, ����, ����, ü��, ���� ���θ� ��ĭ���� �и��Ͽ� �Է��ϼ���");
		Scanner scanner = new Scanner(System.in);
		String name = scanner.next(); 
		System.out.print("�̸��� " + name + ", ");
		String city = scanner.next(); 
		System.out.print("���ô� " + city + ", ");
		int age = scanner.nextInt(); 
		System.out.print("���̴� " + age + "��, ");
		double weight = scanner.nextDouble(); 
		System.out.print("ü���� " + weight + "kg, ");
		boolean single = scanner.nextBoolean();
		System.out.println("���� ���δ� " + single + "�Դϴ�.");
		scanner.close(); 
	}
	public void Integrated()
	{
		ScannerEx Scan = new ScannerEx();
		Scan.getInput();
		SSimpleAdder Adder1 = new SSimpleAdder();
		Adder1.add();
		SSSimpleAdder Adder2 = new SSSimpleAdder();
		Adder2.add();
		TypeExample1 Type1 = new TypeExample1();
		Type1.runType();
		TypeExample2 Type2 = new TypeExample2();
		Type2.runType2();
		LiteralExample4 Literal = new LiteralExample4();
		Literal.runLiteral4();
		runLiteral7 Literal2 = new runLiteral7();
		Literal2.runLiteral();
	}
	public static void main(String[] args) 
	{
		ScannerEx print = new ScannerEx();
		print.Integrated();
	}
}