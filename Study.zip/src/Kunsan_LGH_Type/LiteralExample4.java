package Kunsan_LGH_Type;

public class LiteralExample4 
{
	public void runLiteral4()
	{
		System.out.println(12.025);
		System.out.println(12e3);
		System.out.println(12e-3);
		System.out.println(0xA1.27p5);
	}
	public static void main(String[] args) 
	{
		LiteralExample4 test = new LiteralExample4();
		test.runLiteral4();
	}
}
