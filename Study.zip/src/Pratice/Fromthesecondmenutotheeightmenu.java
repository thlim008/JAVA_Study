package Pratice;

import java.util.Scanner;

public class Fromthesecondmenutotheeightmenu 
{
	Scanner Scan = new Scanner(System.in);
	public void goSecondmenu(Student[] callstudent) {
		System.out.println("�й� �̸� �ּ� ���г⵵ �¾�⵵");
		for (int i = 0; i < callstudent.length; i++) {
			System.out.println(
					callstudent[i].getStudentnumber() + callstudent[i].getStudenname() + callstudent[i].getAddress()
							+ callstudent[i].getStudentadmission() + callstudent[i].getBirthday());
		}
	}

	public void goThirdmenu(Student[] callstudent) {
		System.out.println("�˻��� �л��� �й�:");
		int scanstudentnumber = Scan.nextInt();
		for (int i = 0; i < callstudent.length; i++) {
			int comparenumber = callstudent[i].getStudentnumber();
			if (comparenumber == scanstudentnumber) {
				System.out.println(
						callstudent[i].getStudentnumber() + callstudent[i].getStudenname() + callstudent[i].getAddress()
								+ callstudent[i].getStudentadmission() + callstudent[i].getBirthday());
			}
		}
	}

	public void goFourmenu(Student[] callstudent) {
		int oldbirthyear = callstudent[0].getBirthday();
		int youngbirthyear = callstudent[0].getBirthday();
		int oldage = 0;
		int youngage = 0;
		for (int i = 0; i < callstudent.length; i++) {
			if (oldbirthyear < callstudent[i].getBirthday()) {
				oldbirthyear = callstudent[i].getBirthday();
				oldage = 2022 - oldbirthyear;

			}
			if (youngbirthyear > callstudent[i].getBirthday()) {
				youngbirthyear = callstudent[i].getBirthday();
				youngage = 2022 - youngbirthyear;

			}
			System.out.println("�ְ����� : " + oldbirthyear + "���" + oldage);
			System.out.println("�������� : " + youngbirthyear + "���" + youngage);
		}

	}

	public void goFivemenu(Student[] callstudent) 
	{
		int averageadmission = 0;
		int average = 0;
		float mediannumber = 0;
		int callstudentlength = callstudent.length;
		if (callstudentlength % 2 == 0) 
		{
			int firstnumber = callstudentlength / 2;
			int lastnumber = callstudentlength / 2 - 1;
			mediannumber = (float) (callstudent[firstnumber].getStudentadmission()
					+ callstudent[lastnumber].getStudentadmission()) / 2;
		} 
		else 
		{
			int firstnumber = callstudentlength / 2;
			mediannumber = (float) (callstudent[firstnumber].getStudentadmission());
		}
		for (int i = 0; i < callstudent.length; i++) {
			averageadmission += callstudent[i].getStudentadmission();
		}
		average = averageadmission / callstudent.length;
		System.out.println(average);
		System.out.println(mediannumber);
	}

	public void goSixmenu(Student[] callstudent) 
	{
		Student swap;
		Student[] copyclone = callstudent.clone();
		for (int i = 0; i < callstudent.length; i++) {
			for (int j = 0; j < callstudent.length - i - 1; j++) {
				int studentclone = copyclone[j].getBirthday();
				int studentclone2 = copyclone[j + 1].getBirthday();
				if (studentclone > studentclone2) {
					swap = copyclone[j];
					copyclone[j] = copyclone[j + 1];
					copyclone[j + 1] = swap;
				}
			}
		}
		for (int i = 0; i < copyclone.length; i++) {
			System.out.println(copyclone[i].getBirthday());
		}
	}
	public void goSevenmenu(Student[] callstudent)
	{
		System.out.println("�˻��� �л��� �̸�:");
		String scanstudentname = Scan.next();
		for (int i = 0; i < callstudent.length; i++) {
			String comparescan = callstudent[i].getStudenname();
			if (scanstudentname.equals(comparescan)) {
				System.out.println(
						callstudent[i].getStudentnumber() + callstudent[i].getStudenname() + callstudent[i].getAddress()
								+ callstudent[i].getStudentadmission() + callstudent[i].getBirthday());
			}
		}
	}
	public Student[] goEightStudentmenu(Student[] callstudent)
	{
		System.out.println("������ �й��� �Է��ϼ���:");
		Scanner Scan = new Scanner(System.in);
		int change = Scan.nextInt();
		for(int i = 0; i < callstudent.length; i++)
		{
			if(change == callstudent[i].getStudentnumber())
			{
				callstudent[i].setStudentnumber(Scan.nextInt());
				callstudent[i].setStudentname(Scan.next());
				callstudent[i].setAddress(Scan.next());
				callstudent[i].setStudentadmission(Scan.nextInt());
				callstudent[i].setBirthday( Scan.nextInt());
			}
		}
		return callstudent;
	}
}
