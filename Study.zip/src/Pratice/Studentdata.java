package Pratice;
import java.util.*;
public class Studentdata 
{
	
	public int inputNumberofstudent()
	{
		Scanner studentdata = new Scanner(System.in);
		System.out.println("�Է��� �л��� ������ ��������:");
		int inputstudent = studentdata.nextInt();
		return inputstudent;
	}
	public Student[] goFirststudentmenu(int inputstudent)
	{
		Scanner studentdata = new Scanner(System.in);
		Student[] firststudentmenu = new Student[inputstudent];
		for(int i = 0; i < firststudentmenu.length; i++)
		{
			System.out.print(i+"��° �л� �Է�:");
			int studentnumber = studentdata.nextInt();
			String studentname = studentdata.next(); 
			String address = studentdata.next();
			int studentadmission = studentdata.nextInt();
			int birthday = studentdata.nextInt();
			firststudentmenu[i] = new Student(studentnumber, studentname, address, studentadmission, birthday);
		}
		return firststudentmenu;
	}
}
