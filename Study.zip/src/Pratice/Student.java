package Pratice;

public class Student 
{
	int Studentnumber, Studentadmission, Birthday;
	String Studentname, Address;
	public Student(int Studentnumber,  String Studentname, String Address, int Studentadmission, int Birthday)
	{
		this.Studentnumber = Studentnumber;
		this.Studentadmission = Studentadmission;
		this.Birthday = Birthday;
		this.Studentname = Studentname;
		this.Address = Address;
	}
	public int getStudentnumber()
	{
		return Studentnumber;
	}
	public int getStudentadmission()
	{
		return Studentadmission;
	}
	public int getBirthday()
	{
		return Birthday;
	}
	public String getStudenname()
	{
		return Studentname;
	}
	public String getAddress()
	{
		return Address;
	}
	public void setStudentnumber(int Studentnumber)
	{
		this.Studentnumber = Studentnumber;
	}
	public void setStudentadmission(int Studentadmission)
	{
		this.Studentadmission = Studentadmission;
	}
	public void setBirthday(int Birthday)
	{
		this.Birthday = Birthday;
	}
	public void setStudentname(String Studentname)
	{
		this.Studentname = Studentname;
	}
	public void setAddress(String Address)
	{
		this.Address = Address;
	}
}
