package Pratice2;

public class Student 
{
	int studentnumber, studentadmission, birthyear;
	String name, city;
	public Student(int studentnumber, int studentadmission, int birthyear, String name, String city)
	{
		this.studentnumber = studentnumber;
		this.studentadmission = studentadmission;
		this.birthyear = birthyear;
		this.name = name;
		this.city = city;
	}
	public int getStudentnumber()
	{
		return studentnumber;
	}
	public int getStudentadmission()
	{
		return studentadmission;
	}
	public int getBirthyear()
	{
		return birthyear;
	}
	public String getName()
	{
		return name;
	}
	public String getCity()
	{
		return city;
	}
	public void setStudentnumber(int studentnumber)
	{
		this.studentnumber = studentnumber;
	}
	public void setStudentadmission(int studentadmission)
	{
		this.studentadmission = studentadmission;
	}
	public void setBirthyear(int birthyear)
	{
		this.birthyear = birthyear;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setCity(String city)
	{
		this.city = city;
	}
}
