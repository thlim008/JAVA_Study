package Pratice2;
import java.util.*;
public class Function 
{
	Scanner Scan = new Scanner(System.in);
	public int selctStudentnumber()
	{
		System.out.println("����� �����ðڽ��ϱ�?");
		int selectnumber = Scan.nextInt();
		return selectnumber;
	}
	public Student[] setStudentrecord(int selectnumber)
	{
		Student[] studentarray = new Student[selectnumber];
		for(int i = 0; i< studentarray.length; i++)
		{
			System.out.print(i + "��° �л�");
			int studentnumber = Scan.nextInt();
			int studentadmission = Scan.nextInt();
			int studentbirthyear = Scan.nextInt();
			String name = Scan.next();
			String city = Scan.next();
			studentarray[i] = new Student(studentnumber, studentadmission, studentbirthyear, name, city);
			
		}
		return studentarray;
	}
	public void showStudents(Student[] studentarray)
	{
		for(int i = 0; i < studentarray.length; i++)
		{
			System.out.println(studentarray[i].getStudentnumber() + studentarray[i].getStudentadmission() +studentarray[i].getBirthyear() +studentarray[i].getName() +studentarray[i].getCity());
		}
	}
	public void showStudent(Student[] studentarray)
	{
		int selctstudent = Scan.nextInt();
		for(int i = 0; i< studentarray.length; i++)
		{
			if(selctstudent == i)
			{
				System.out.println(studentarray[i].getStudentnumber() + studentarray[i].getStudentadmission() +studentarray[i].getBirthyear() +studentarray[i].getName() +studentarray[i].getCity());
			}
		}
	}
	public void showMaxminage(Student[] studentarray)
	{
		int maxage = studentarray[0].getBirthyear();
		int minage = studentarray[0].getBirthyear();
		for(int i = 0; i< studentarray.length; i++)
		{
			if(maxage > studentarray[i].getBirthyear())
			{
				maxage = studentarray[i].getBirthyear();
			}
			if(minage < studentarray[i].getBirthyear())
			{
				minage = studentarray[i].getBirthyear();
			}
		}
		System.out.println(maxage);
		System.out.println(minage);
	}
	public void showAdmission(Student[] studentarray)
	{
		int studentarraylength = studentarray.length;
		int average = 0;
		int averageadd = 0;
		float median = 0;
		for(int i = 0; i < studentarray.length; i++)
		{
			averageadd += studentarray[i].getBirthyear();
		}
		average = averageadd / studentarraylength;
		if(studentarray.length % 2 ==0)
		{
			int mediantemp = studentarraylength/2;//
			int mediantemp2 = studentarraylength/2-1;//
			median = (float)((studentarray[mediantemp].getBirthyear() + studentarray[mediantemp2].getBirthyear()) /2);//
		}
		else {
			int mediantemp = studentarraylength/2;
			median= (float)(studentarray[mediantemp].getBirthyear()/2);
		}
	}
	public void showSortage(Student[] studentarray)
	{
		Student swap;
		Student[] ageclone = studentarray.clone();
		for(int i = 0; i< studentarray.length; i++)
		{
			for(int j = 0; j< studentarray.length-i-1; j++)
			{
				int studentnowage = ageclone[j].getBirthyear();//
				int studentnextage = ageclone[j+1].getBirthyear();//
				if(studentnowage > studentnextage)
				{
					swap = ageclone[j];
					ageclone[j]  =  ageclone[j+1];
					ageclone[j+1] = swap;
				}
			}
		}
		for(int i = 0; i< ageclone.length; i++)
		{
			System.out.println(ageclone[i].getStudentnumber() + ageclone[i].getStudentadmission() +ageclone[i].getBirthyear() +ageclone[i].getName() +ageclone[i].getCity());
		}
	}
	public void fineName(Student[] studentarray)
	{
		String selctname = Scan.next();
		for(int i = 0; i< studentarray.length; i++)
		{
			String name = studentarray[i].getName();
			if(selctname.compareTo(name)>0)
			{
				System.out.println(studentarray[i].getStudentnumber() + studentarray[i].getStudentadmission() +studentarray[i].getBirthyear() +studentarray[i].getName() +studentarray[i].getCity());
			}
		}
	}
	public Student[] changeInformation(Student[] studentarray)
	{
		int changenumber = Scan.nextInt();
		for(int i = 0; i< studentarray.length; i++)
		{
			if(changenumber == studentarray[i].getStudentnumber())
			{
				studentarray[i].setStudentnumber(Scan.nextInt());
				studentarray[i].setStudentadmission(Scan.nextInt());
				studentarray[i].setBirthyear(Scan.nextInt());
				studentarray[i].setName(Scan.next());
				studentarray[i].setCity(Scan.next());
			}
		}
		return studentarray;
	}
}
